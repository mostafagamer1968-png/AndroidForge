package com.omar.miraculouslauncher

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Starter launcher/theme app for Samsung Galaxy A04e / Android 14.
 * It lets the user choose an image and apply it as home + lock wallpaper,
 * then lists installed launchable apps. It does not silently change system icons.
 */
class MainActivity : Activity() {
    private val red = Color.rgb(226, 20, 59)
    private val black = Color.rgb(16, 9, 15)
    private val cream = Color.rgb(255, 244, 246)
    private var selectedImage: Uri? = null
    private lateinit var root: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var applyButton: Button
    private val openImage = 2417

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        selectedImage = savedInstanceState?.getString("image_uri")?.let { Uri.parse(it) }
        buildUi()
        selectedImage?.let { showPreview(it) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        selectedImage?.let { outState.putString("image_uri", it.toString()) }
        super.onSaveInstanceState(outState)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(black) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "MIRACULOUS\nTHEME"
            textSize = 29f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
            letterSpacing = 0.08f
            setPadding(0, dp(12), 0, dp(6))
        }
        root.addView(title, matchWrap())
        root.addView(label("LADYBUG • CAT NOIR • RED & BLACK", red, 12f, true), matchWrap())

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(cream, 22)
            clipToOutline = true
            contentDescription = "Preview of selected theme image"
        }
        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(48, 22, 31), 22)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(preview, FrameLayout.LayoutParams(-1, -1))
        }
        val previewLp = LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(22); bottomMargin = dp(14) }
        root.addView(frame, previewLp)

        root.addView(actionButton("1  •  CHOOSE YOUR THEME IMAGE", red) { chooseImage() }, matchWrap().also { it.topMargin = dp(5) })
        applyButton = actionButton("2  •  APPLY AS WALLPAPER", Color.rgb(104, 20, 43)) { applyWallpaper() }
        applyButton.isEnabled = selectedImage != null
        root.addView(applyButton, matchWrap().also { it.topMargin = dp(10) })

        root.addView(label("YOUR APPS", Color.WHITE, 18f, true).apply {
            setPadding(2, dp(26), 0, dp(10))
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Tap an app to open it. This starter version keeps Android's original app icons; custom character icons are a later step."
            textSize = 13f
            setTextColor(Color.rgb(207, 187, 195))
        }, matchWrap())
        root.addView(buildAppGrid(), matchWrap().also { it.topMargin = dp(12) })

        root.addView(TextView(this).apply {
            text = "Note: Android requires your approval to set wallpapers. This app does not change system settings secretly. To use this as your home screen, choose “Miraculous Theme” in Settings → Apps → Default apps → Home app."
            textSize = 12f
            setTextColor(Color.rgb(179, 159, 168))
            setPadding(2, dp(22), 2, 0)
        }, matchWrap())
        setContentView(scroll)
    }

    private fun buildAppGrid(): View {
        val grid = GridLayout(this).apply { columnCount = 4; alignmentMode = GridLayout.ALIGN_BOUNDS }
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(40)
        for (app in apps) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(8), dp(3), dp(8))
                isClickable = true
                isFocusable = true
                background = rounded(Color.rgb(32, 20, 27), 14)
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.loadIcon(pm))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            val name = TextView(this).apply {
                text = app.loadLabel(pm).toString()
                textSize = 10f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            }
            item.addView(name, LinearLayout.LayoutParams(-1, dp(32)))
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            grid.addView(item, lp)
        }
        if (apps.isEmpty()) {
            grid.addView(label("No launchable apps found", Color.WHITE, 13f, false))
        }
        return grid
    }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, openImage)
    }

    @Deprecated("Using Activity Result API can be added in a future version")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == openImage && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedImage = uri
            showPreview(uri)
            applyButton.isEnabled = true
        }
    }

    private fun showPreview(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                preview.setImageBitmap(BitmapFactory.decodeStream(input))
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open this image. Please choose another.", Toast.LENGTH_LONG).show()
        }
    }

    private fun applyWallpaper() {
        val uri = selectedImage ?: run {
            Toast.makeText(this, "Choose an image first.", Toast.LENGTH_SHORT).show(); return
        }
        try {
            val bitmap: Bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw IllegalStateException("Image could not be read")
            WallpaperManager.getInstance(this).setBitmap(
                bitmap, null, true,
                WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            )
            Toast.makeText(this, "Wallpaper applied to Home and Lock screens!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Android could not apply this image: ${e.localizedMessage ?: "try another image"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
